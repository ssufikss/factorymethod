using System.Text;
using CarFactoryLib;

Console.OutputEncoding = Encoding.UTF8;

Console.WriteLine("Каталог автомобілів (патерн Фабричний метод):");
Console.WriteLine("1 - Honda");
Console.WriteLine("2 - BMW");
Console.WriteLine("3 - Mercedes-Benz");
Console.Write("Оберіть марку авто (1-3): ");

string? choice = Console.ReadLine();

CarCatalogCreator factory = choice switch
{
    "1" => new HondaFactory(),
    "2" => new BmwFactory(),
    "3" => new MercedesFactory(),
    _ => new HondaFactory()
};

factory.DemonstrateCar();
