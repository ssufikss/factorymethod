namespace CarFactoryLib
{
    // Загальний інтерфейс продукту
    public interface ICar
    {
        string Brand { get; }
        string Model { get; }
        void OpenDoors();
        void TurnOnHeadlights();
        void Drive();
    }

    // 3 реальні об'єкти (Конкретні продукти)
    public class HondaCar : ICar
    {
        public string Brand => "Honda";
        public string Model => "Civic";

        public void OpenDoors() => Console.WriteLine($"[{Brand} {Model}] Відкриття 4 стандартних дверей.");
        public void TurnOnHeadlights() => Console.WriteLine($"[{Brand} {Model}] Увімкнено світлодіодні фари.");
        public void Drive() => Console.WriteLine($"[{Brand} {Model}] Економічний режим руху в місті.");
    }

    public class BmwCar : ICar
    {
        public string Brand => "BMW";
        public string Model => "M5";

        public void OpenDoors() => Console.WriteLine($"[{Brand} {Model}] Плавне відкриття дверей із доводчиками.");
        public void TurnOnHeadlights() => Console.WriteLine($"[{Brand} {Model}] Увімкнено лазерну оптику BMW Laserlight.");
        public void Drive() => Console.WriteLine($"[{Brand} {Model}] Спортивний режим із максимальною динамікою.");
    }

    public class MercedesCar : ICar
    {
        public string Brand => "Mercedes-Benz";
        public string Model => "E-Class";

        public void OpenDoors() => Console.WriteLine($"[{Brand} {Model}] Безключовий доступ Keyless-Go.");
        public void TurnOnHeadlights() => Console.WriteLine($"[{Brand} {Model}] Увімкнено адаптивні фари Multibeam LED.");
        public void Drive() => Console.WriteLine($"[{Brand} {Model}] Комфортний хід із пневмопідвіскою.");
    }

    // Базовий клас-творець із фабричним методом
    public abstract class CarCatalogCreator
    {
        public abstract ICar CreateCar();

        public void DemonstrateCar()
        {
            ICar car = CreateCar();
            Console.WriteLine($"\n--- Демонстрація автомобіля з каталогу: {car.Brand} {car.Model} ---");
            car.OpenDoors();
            car.TurnOnHeadlights();
            car.Drive();
        }
    }

    // 3 реальні фабрики (Конкретні творці)
    public class HondaFactory : CarCatalogCreator
    {
        public override ICar CreateCar() => new HondaCar();
    }

    public class BmwFactory : CarCatalogCreator
    {
        public override ICar CreateCar() => new BmwCar();
    }

    public class MercedesFactory : CarCatalogCreator
    {
        public override ICar CreateCar() => new MercedesCar();
    }
}
